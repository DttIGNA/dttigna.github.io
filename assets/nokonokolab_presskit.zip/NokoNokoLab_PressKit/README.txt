NokoNokoLab Press Kit (2026-11)
===============================
Contents: app icons, logos, key art and screenshots of
  - ドット野球部 高校野球シミュレーション / Pixel Baseball Club (App Store: https://apps.apple.com/jp/app/id6790614262)
  - Golf School Manager / プロゴルファーを育てよう (App Store: https://apps.apple.com/jp/app/id6818499829)

Usage: free to use for reviews, articles, social media posts, videos and streams
(including monetized ones). Please credit "NokoNokoLab" and do not present the
material as your own or imply official endorsement. Do not resell or redistribute
the files as asset packs. Contact / collaboration: https://note.com/ripe_viper255/n/n5610f3cdbdc1
Site: https://dttigna.github.io/
